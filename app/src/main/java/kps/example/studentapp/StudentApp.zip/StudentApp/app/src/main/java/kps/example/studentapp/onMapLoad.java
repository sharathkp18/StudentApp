package kps.example.studentapp;

public interface onMapLoad {
    void onMapLoaded();
}
